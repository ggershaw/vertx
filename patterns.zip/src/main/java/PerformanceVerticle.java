import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.ext.dropwizard.MetricsService;

public class PerformanceVerticle extends AbstractVerticle implements Handler<Long>{
    private MetricsService service;


    @Override
    public void start(Future<Void> startFuture) throws Exception {
        service = MetricsService.create(vertx);
        vertx.setPeriodic(15000, this);

    }

    @Override
    public void handle(Long aLong) {
        System.out.println(service.getMetricsSnapshot("vertx.sender.count"));
    }
}
