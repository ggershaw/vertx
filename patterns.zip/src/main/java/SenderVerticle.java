import com.codahale.metrics.Meter;
import com.codahale.metrics.SharedMetricRegistries;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Handler;

public class SenderVerticle extends AbstractVerticle implements Handler<Long>{
    private Meter meter;

    public SenderVerticle(){
       meter =  SharedMetricRegistries.setDefault("registry").meter("sender.count");
    }
    @Override
    public void start() throws Exception {
        vertx.setPeriodic(5000, this);
    }

    public void handle(Long aLong) {
        meter.mark();
        vertx.eventBus().publish("testTopic", "testMsg");
    }
}
