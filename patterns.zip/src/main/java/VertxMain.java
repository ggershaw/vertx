import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.VertxOptions;
import io.vertx.ext.dropwizard.DropwizardMetricsOptions;

public class VertxMain {

    public static void main(String[] args) {
        Vertx vertx  = Vertx.vertx(new VertxOptions()
                .setMetricsOptions(new DropwizardMetricsOptions().setEnabled(true)));
        vertx.deployVerticle(new SenderVerticle());
        vertx.deployVerticle(new ReceiverVerticle());
        vertx.deployVerticle(new PerformanceVerticle());
    }

}
