import org.junit.Before;

import static org.junit.Assert.*;

public class SubjectImplTest {

    @Before
    public void setUp() throws Exception {

    }

    @org.junit.Test
    public void registerObserver() {
    }

    @org.junit.Test
    public void unregisterObserver() {
    }

    @org.junit.Test
    public void notifyObservers() {
    }
}